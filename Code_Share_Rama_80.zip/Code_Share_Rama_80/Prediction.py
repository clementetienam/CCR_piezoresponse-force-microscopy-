# -*- coding: utf-8 -*-
"""
Created on Tuesday November 06 12:05:47 2019

@author: Dr Clement Etienam
Supervisor: Professor Kody Law
Prediction of test data 
"""
from __future__ import print_function
print(__doc__)
import numpy as np
from sklearn import metrics
import matplotlib.pyplot as plt
import datetime
from sklearn.preprocessing import MinMaxScaler
import pickle
import os
import shutil
import multiprocessing
from scipy.stats import rankdata, norm
from numpy import linalg as LA
import pandas as pd
## This section is to prevent Windows from sleeping when executing the Python script
class WindowsInhibitor:
    '''Prevent OS sleep/hibernate in windows; code from:
    https://github.com/h3llrais3r/Deluge-PreventSuspendPlus/blob/master/preventsuspendplus/core.py
    API documentation:
    https://msdn.microsoft.com/en-us/library/windows/desktop/aa373208(v=vs.85).aspx'''
    ES_CONTINUOUS = 0x80000000
    ES_SYSTEM_REQUIRED = 0x00000001

    def __init__(self):
        pass

    def inhibit(self):
        import ctypes
        #Preventing Windows from going to sleep
        ctypes.windll.kernel32.SetThreadExecutionState(
            WindowsInhibitor.ES_CONTINUOUS | \
            WindowsInhibitor.ES_SYSTEM_REQUIRED)

    def uninhibit(self):
        import ctypes
        #Allowing Windows to go to sleep
        ctypes.windll.kernel32.SetThreadExecutionState(
            WindowsInhibitor.ES_CONTINUOUS)


osSleep = None
# in Windows, prevent the OS from sleeping while we run
if os.name == 'nt':
    osSleep = WindowsInhibitor()
    osSleep.inhibit()
##------------------------------------------------------------------------------------

## Start of Programme

print( 'Standalone prediction for TGLF ')
oldfolder = os.getcwd()
cores = multiprocessing.cpu_count()
print(' ')
print(' This computer has %d cores, which will all be utilised in parallel '%cores)
#print(' The number of cores to be utilised can be changed in runeclipse.py and writefiles.py ')
print(' ')
from scipy import interpolate
start = datetime.datetime.now()
print(str(start))
def interpolatebetween(xtrain,cdftrain,xnew):
    numrows1=len(xnew)
    numcols = len(xnew[0])
    norm_cdftest2=np.zeros((numrows1,numcols))

    for i in range(numcols):
        a=xtrain[:,i]
        b=cdftrain[:,i]
        f = interpolate.interp1d(a, cdftrain[:,i],kind='linear',fill_value=(b.min(), b.max()),bounds_error=False)
        cdftest = f(xnew[:,i])
        norm_cdftest2[:,i]=np.ravel(cdftest)
    return norm_cdftest2

def gaussianizeit(input1):
    numrows1=len(input1)
    numcols = len(input1[0])
    newbig=np.zeros((numrows1,numcols))
    for i in range(numcols):
        input11=input1[:,i]
        newX = norm.ppf(rankdata(input11)/(len(input11) + 1))
        newbig[:,i]=newX.T
    return newbig

def sort_data_prediction(train_x,train_y,test_x,test_y):
	matrix_train=np.concatenate((train_x,train_y), axis=1)
	matrix_test=np.concatenate((test_x,test_y), axis=1)

	overall_matrix=np.concatenate((matrix_train,matrix_test), axis=0)
	overall=sorted(overall_matrix , key=lambda k: [k[2], k[1], k[0]])
	overall=(np.asarray(overall))
	return overall
	
#------------------Begin Code-----------------------------------------------------------------#
print('Load the input data you want to predict from')

print('-------------------LOAD INPUT DATA---------------------------------')
print('  Loading the training data wit X Y Z Cordinates ')
data=np.genfromtxt("data.out", dtype='float')
test=data
input1=np.genfromtxt("trainX.out", dtype='float')
output=np.genfromtxt("trainY.out", dtype='float')

output=np.reshape(output,(-1,1),'F')

scaler2 = MinMaxScaler()
(scaler2.fit(output))
yruth=(scaler2.transform(output))

#scaler = MinMaxScaler()
#(scaler.fit(input1))
#input1=(scaler.transform(input1))

print('')
scaler = MinMaxScaler()
input2=gaussianizeit(input1)
input2= scaler.fit(input2).transform(input2)

print('  Loading the test data with X Y Z cordinates ')
inputtest=np.genfromtxt("testX.out", dtype='float')
inputtest2=inputtest
outputtest=np.genfromtxt("testY.out", dtype='float')


outputtest=np.reshape(outputtest,(-1,1),'F')

clement=interpolatebetween(input1,input2,inputtest)
#inputtest=scaler.transform(inputtest)

inputtest=clement
outputfirst=output
output2=outputfirst
scaler2 = MinMaxScaler()
output2=gaussianizeit(output2)
output2= scaler2.fit(output2).transform(output2)
print('')
print('Standardize and normalize (make gaussian) the test data')

numrows1=len(inputtest) 


numrows=len(inputtest)    # rows of input
numrowstest=numrows
numcols = len(inputtest[0])
numruth = numcols
print('')
print(' Determine how many clusters were used for training CCR')
clementr = len([i for i in os.listdir(oldfolder) if os.path.isdir(i)])


nclusters=int(clementr)


numcolstest = 1


filename1= 'Claffiermodel1.asv'
loaded_model = pickle.load(open(filename1, 'rb'))
labelDA = loaded_model.predict(inputtest)
labelDA=np.argmax(labelDA, axis=-1) 

#-------------------Regression prediction---------------------------------------------------#

oldfolder = os.getcwd()
os.chdir(oldfolder)
filename1='regressor1.asv'
clementanswer1=np.zeros((numrowstest,1))
print('')    
print('predict in series')
for i in range(nclusters):
    folder = 'CCRmodel1_%d'%(i)
    os.chdir(folder)    
    loaded_model = pickle.load(open(filename1, 'rb'))

    
    labelDA0=(np.asarray(np.where(labelDA == i))).T


##----------------------##------------------------##
    a00=inputtest[labelDA0,:]
    a00=np.reshape(a00,(-1,numruth),'F')
    if a00.shape[0]!=0:
        clementanswer1[np.ravel(labelDA0),:]=np.reshape(loaded_model .predict(a00),(-1,1))
    os.chdir(oldfolder)

clementanswer1=interpolatebetween(output2,outputfirst,clementanswer1)
print('')
print('recombine this test points with training points')
train_indices=np.genfromtxt("indices_train.out", dtype='float')
test_indices=np.genfromtxt("indices_test.out", dtype='float')
"""
Ttrain=np.reshape(train_indices,(-1,1),'F')
Ttest=np.reshape(test_indices,(-1,1),'F')

numrows_train=len(Ttrain) 
numrows_test=len(Ttest) 

clement2_answer=np.zeros((numrows_train+numrows_test,1))
clement2_answer[train_indices,:]=output
clement2_answer[test_indices,:]=clementanswer1
"""

clement2_answer=sort_data_prediction(input1,output,inputtest2,clementanswer1)
True_data=sort_data_prediction(input1,output,inputtest2,outputtest)

def all_error (CCR,Trued):
    clementanswer1=np.reshape(CCR,(-1,1))

	
    outputtest1=np.reshape(Trued,(-1,1))

    numrowstest=len(outputtest1)

    outputtest1 = np.reshape(outputtest1, (-1, 1))
    Lerrorsparse=(LA.norm(outputtest1-clementanswer1)/LA.norm(outputtest1))**0.5
    L_21=1-(Lerrorsparse**2)
	#Coefficient of determination
    outputreq=np.zeros((numrowstest,1))
    for i in range(numrowstest):
        outputreq[i,:]=outputtest1[i,:]-np.mean(outputtest1)

	#outputreq=outputreq.T
    CoDspa=1-(LA.norm(outputtest1-clementanswer1)/LA.norm(outputreq))
    CoD1=1 - (1-CoDspa)**2 
    L1_error=sum(np.absolute(clementanswer1-outputtest1))
    L2_error=(sum((clementanswer1-outputtest1)**2))**0.5
    
    errors=sum(np.absolute(1-(clementanswer1/outputtest1)))

    print ('R2 accuracy of fit using the machine for output 1 is :', CoD1)
    print ('L2 accuracy of fit using the machine for output 1 is :', L_21)
    print ('L1 error of fit using the machine for output 1 is :', L1_error)
    print ('L2 error of fit using the machine for output 1 is :', L2_error)
    print ('relative error of fit using the machine for output 1 is :', errors)
    print('Mean Absolute Error of CCR:', metrics.mean_absolute_error(clementanswer1,outputtest1))  
    print('Mean Squared Error of CCR:', metrics.mean_squared_error(clementanswer1,outputtest1))  
    print('Root Mean Squared Error of CCR:', np.sqrt(metrics.mean_squared_error(clementanswer1,outputtest1)))

print('')
all_error (clement2_answer[:,3],True_data[:,3])

import matplotlib.colors as colors
def best_fit(X, Y):

    xbar = sum(X)/len(X)
    ybar = sum(Y)/len(Y)
    n = len(X) # or len(Y)

    numer = sum([xi*yi for xi,yi in zip(X, Y)]) - n * xbar * ybar
    denum = sum([xi**2 for xi in X]) - n * xbar**2

    b = numer / denum
    a = ybar - b * xbar

    print('best fit line:\ny = {:.2f} + {:.2f}x'.format(a, b))

    return a, b
from copy import copy
def plot2Dhistogram(CCR,Trued,string1):
	print(' Compute L2 and R2 for the 6 machine')
	clementanswer1=np.reshape(CCR,(-1,1))

	outputtest1=np.reshape(Trued,(-1,1))

	numrowstest=len(outputtest1)
    
	outputtest1 = np.reshape(outputtest1, (-1, 1))
	Lerrorsparse=(LA.norm(outputtest1-clementanswer1)/LA.norm(outputtest1))**0.5
	L_21=1-(Lerrorsparse**2)
	#Coefficient of determination
	outputreq=np.zeros((numrowstest,1))
	for i in range(numrowstest):
		outputreq[i,:]=outputtest1[i,:]-np.mean(outputtest1)

	#outputreq=outputreq.T
	CoDspa=1-(LA.norm(outputtest1-clementanswer1)/LA.norm(outputreq))
	CoD1=1 - (1-CoDspa)**2 ;
	print ('R2 of fit using the machine for output 1 is :', CoD1)
	print ('L2 of fit using the machine for output 1 is :', L_21)
	print('')

	
	
	


	print('')
	#
	print('Plot figures')
	plt.figure(figsize =(10,10),facecolor='w')
	cm = plt.cm.get_cmap('inferno_r')
	palette = copy(plt.get_cmap('inferno_r'))
	palette.set_under('white')  # 1.0 represents not transparent
	palette.set_over('black')  # 1.0 represents not transparent
	
	vmin=min(np.ravel(outputtest1[:,:]))
	vmax=max(np.ravel(outputtest1[:,:]))
	
	sc=plt.hist2d(np.ravel(clementanswer1[:,:]),np.ravel(outputtest1[:,:]), bins=(50, 50),vmin=vmin,vmax=vmax, cmap=palette,norm=colors.SymLogNorm(linthresh=0.03, linscale=0.03,vmin=vmin, vmax=vmax))

	plt.clim(0,vmax)

	plt.colorbar()
    
    
	plt.title('RAMA_data', fontsize = 10)
    
    
	
	a,b=best_fit(np.ravel(clementanswer1[:,:]), np.ravel(outputtest1[:,:]),)
	yfit = [a + b * xi for xi in np.ravel(clementanswer1[:,:])]
	plt.plot(np.ravel(clementanswer1[:,:]), yfit,'--',color='b',linewidth=0.5)
	plt.annotate('R2= %.3f' % CoD1, (0.8, 0.2), xycoords='axes fraction', ha='center', va='center', size=10)
	plt.savefig("%s.pdf"%string1)    
	plt.show()
    
plot2Dhistogram(clement2_answer[:,3],True_data[:,3],"CCR2hist")
def Performance_plot(CCR,Trued,string):
	print(' Compute L2 and R2 for the machine')
	clementanswer1=np.reshape(CCR,(-1,1))

	
	outputtest1=np.reshape(Trued,(-1,1))

	numrowstest=len(outputtest1)
	print('For output 1')
	outputtest1 = np.reshape(outputtest1, (-1, 1))
	Lerrorsparse=(LA.norm(outputtest1-clementanswer1)/LA.norm(outputtest1))**0.5
	L_21=1-(Lerrorsparse**2)
	#Coefficient of determination
	outputreq=np.zeros((numrowstest,1))
	for i in range(numrowstest):
		outputreq[i,:]=outputtest1[i,:]-np.mean(outputtest1)

	#outputreq=outputreq.T
	CoDspa=1-(LA.norm(outputtest1-clementanswer1)/LA.norm(outputreq))
	CoD1=1 - (1-CoDspa)**2 ;
	print ('R2 of fit using the machine for output 1 is :', CoD1)
	print ('L2 of fit using the machine for output 1 is :', L_21)
	print('')

	
	
	
	CoDoverall=CoD1
	R2overall=L_21
    
      
	


	print('')
	#
	print('Plot figures')
	plt.figure(figsize =(7,7))
	cm = plt.cm.get_cmap('inferno_r')
	palette = copy(plt.get_cmap('inferno_r'))
	palette.set_under('white')  # 1.0 represents not transparent
	palette.set_over('black')  # 1.0 represents not transparent

	vmin=min(np.ravel(outputtest1))
	vmax=max(np.ravel(outputtest1))
	sc=plt.scatter(np.ravel(clementanswer1),np.ravel(outputtest1),c=np.ravel(outputtest1), vmin=vmin, vmax=vmax, s=35, cmap=palette)
	plt.colorbar(sc)
	plt.title('PFM data', fontsize = 10)


	
	a,b=best_fit(np.ravel(clementanswer1), np.ravel(outputtest1),)
	yfit = [a + b * xi for xi in np.ravel(clementanswer1)]
	plt.plot(np.ravel(clementanswer1), yfit,color='r')
	plt.annotate('R2= %.3f' % CoD1, (0.8, 0.2), xycoords='axes fraction', ha='center', va='center', size=10)
	



	plt.savefig("%s.pdf"%string)

	plt.show()
	
	return CoDoverall,R2overall
Performance_plot(clement2_answer[:,3],True_data[:,3],"CCR3")
print('Save predictions to file')

header = '%5s'%('RAMA')
valueCCR2=clementanswer1
np.savetxt('CCRprediction.out',valueCCR2, fmt = '%4.6f',delimiter='\t', newline = '\n')

np.savetxt('CCRprediction_big.out',clement2_answer, fmt = '%4.4f',delimiter='\t', newline = '\n')
np.savetxt('True_data.out',True_data, fmt = '%4.4f',delimiter='\t', newline = '\n')

ROLAND ="matlab -r Plot_EELS_Result"
os.system(ROLAND)
print('-------------------END PREDICTION PROGRAM----------------------------')    







