# -*- coding: utf-8 -*-
"""
Created on Tuesday November 05 12:05:47 2019
@author: Dr Clement Etienam
Supervisor: Professor Kody Law
This code is to train CCR for the EELS data set
Size of data set is 50*50*100
Some data will be used in training and the rest used for testing
Parralel CCR
Logic:
1) Determine optimum number of clusters of X and y pair
2) Do K-means custering of the X,y pair obtain cluster label d
3) Create Folder equal to number of clusters determined from elbow in step 1
4) Build classifier of X and d, save the classifier model
5) Build regressors in parallel for each cluster of X and y and save model using Joblib
6) Predict for test data in series

Important steps for CCR to be succesful
1) Make each column of the training input matrix (X) to follow a 'Gaussian distribution'
2) During clustering when concatenating the X,y matrix together, make a copy of y (new_y) and increase magnitude of ' new_y' 
3) During regression resclae 'y' to be between 0 and 1, to make the regression easier
4) Dont forget to backtransform the prediction to original scale
"""
from __future__ import print_function
print(__doc__)

import numpy as np
from sklearn.cluster import MiniBatchKMeans
from scipy.spatial.distance import cdist
import matplotlib.pyplot as plt
import datetime
from sklearn.preprocessing import MinMaxScaler
import pickle
import os
import shutil
import multiprocessing
from scipy import interpolate
from kneed import KneeLocator
from sklearn.cluster import KMeans
from numpy import linalg as LA
from scipy.stats import rankdata, norm
## This section is to prevent Windows from sleeping when executing the Python script
class WindowsInhibitor:
    '''Prevent OS sleep/hibernate in windows; code from:
    https://github.com/h3llrais3r/Deluge-PreventSuspendPlus/blob/master/preventsuspendplus/core.py
    API documentation:
    https://msdn.microsoft.com/en-us/library/windows/desktop/aa373208(v=vs.85).aspx'''
    ES_CONTINUOUS = 0x80000000
    ES_SYSTEM_REQUIRED = 0x00000001

    def __init__(self):
        pass

    def inhibit(self):
        import ctypes
        #Preventing Windows from going to sleep
        ctypes.windll.kernel32.SetThreadExecutionState(
            WindowsInhibitor.ES_CONTINUOUS | \
            WindowsInhibitor.ES_SYSTEM_REQUIRED)

    def uninhibit(self):
        import ctypes
        #Allowing Windows to go to sleep
        ctypes.windll.kernel32.SetThreadExecutionState(
            WindowsInhibitor.ES_CONTINUOUS)


osSleep = None
# in Windows, prevent the OS from sleeping while we run
if os.name == 'nt':
    osSleep = WindowsInhibitor()
    osSleep.inhibit()
##------------------------------------------------------------------------------------

## Start of Programme

print( 'Parallel CCR for TGLF ')


oldfolder = os.getcwd()
cores = multiprocessing.cpu_count()
print(' ')
print(' This computer has %d cores, which will all be utilised in parallel '%cores)
#print(' The number of cores to be utilised can be changed in runeclipse.py and writefiles.py ')
print(' ')

start = datetime.datetime.now()
print(str(start))


print('-------------------LOAD FUNCTIONS---------------------------------')
def interpolatebetween(xtrain,cdftrain,xnew):
    numrows1=len(xnew)
    numcols = len(xnew[0])
    norm_cdftest2=np.zeros((numrows1,numcols))
    for i in range(numcols):
        f = interpolate.interp1d((xtrain[:,i]), cdftrain[:,i],kind='linear')
        cdftest = f(xnew[:,i])
        norm_cdftest2[:,i]=np.ravel(cdftest)
    return norm_cdftest2

def gaussianizeit(input1):
    numrows1=len(input1)
    numcols = len(input1[0])
    newbig=np.zeros((numrows1,numcols))
    for i in range(numcols):
        input11=input1[:,i]
        newX = norm.ppf(rankdata(input11)/(len(input11) + 1))
        newbig[:,i]=newX.T
    return newbig
def getoptimumk(X,i):
    X=matrix
    distortions = []
    Kss = range(1,60)
    
    for k in Kss:
        kmeanModel = MiniBatchKMeans(n_clusters=k).fit(X)
        kmeanModel.fit(X)
        distortions.append(sum(np.min(cdist(X, kmeanModel.cluster_centers_, 'euclidean'), axis=1)) / X.shape[0])
    #ncusters2=np.where(distortions == distortions.min())
    
    myarray = np.array(distortions)
    
    knn = KneeLocator(Kss,myarray,curve='convex',direction='decreasing',interp_method='interp1d')
    kuse=knn.knee
    
    # Plot the elbow
    plt.figure(figsize=(7, 7))
    plt.plot(Kss, distortions, 'bx-')
    plt.xlabel('cluster size')
    plt.ylabel('Distortion')
    plt.title('Elbow Method showing the optimal n_clusters fr machine%d'%(i))
    plt.show()
    return kuse

import matplotlib.colors as colors
def best_fit(X, Y):

    xbar = sum(X)/len(X)
    ybar = sum(Y)/len(Y)
    n = len(X) # or len(Y)

    numer = sum([xi*yi for xi,yi in zip(X, Y)]) - n * xbar * ybar
    denum = sum([xi**2 for xi in X]) - n * xbar**2

    b = numer / denum
    a = ybar - b * xbar

    print('best fit line:\ny = {:.2f} + {:.2f}x'.format(a, b))

    return a, b
from copy import copy
def plot2Dhistogram(CCR,Trued,string1):
	print(' Compute L2 and R2 for the 6 machine')
	clementanswer1=np.reshape(CCR,(-1,1))

	outputtest1=np.reshape(Trued,(-1,1))

	numrowstest=len(outputtest1)
    
	outputtest1 = np.reshape(outputtest1, (-1, 1))
	Lerrorsparse=(LA.norm(outputtest1-clementanswer1)/LA.norm(outputtest1))**0.5
	L_21=1-(Lerrorsparse**2)
	#Coefficient of determination
	outputreq=np.zeros((numrowstest,1))
	for i in range(numrowstest):
		outputreq[i,:]=outputtest1[i,:]-np.mean(outputtest1)

	#outputreq=outputreq.T
	CoDspa=1-(LA.norm(outputtest1-clementanswer1)/LA.norm(outputreq))
	CoD1=1 - (1-CoDspa)**2 ;
	print ('R2 of fit using the machine for output 1 is :', CoD1)
	print ('L2 of fit using the machine for output 1 is :', L_21)
	print('')

	print('')
	#
	print('Plot figures')
	plt.figure(figsize =(10,10),facecolor='w')
	cm = plt.cm.get_cmap('inferno_r')
	palette = copy(plt.get_cmap('inferno_r'))
	palette.set_under('white')  # 1.0 represents not transparent
	palette.set_over('black')  # 1.0 represents not transparent
	
	vmin=min(np.ravel(outputtest1[:,:]))
	vmax=max(np.ravel(outputtest1[:,:]))
	
	sc=plt.hist2d(np.ravel(clementanswer1[:,:]),np.ravel(outputtest1[:,:]), bins=(50, 50),vmin=vmin,vmax=vmax, cmap=palette,norm=colors.SymLogNorm(linthresh=0.03, linscale=0.03,vmin=vmin, vmax=vmax))

	plt.clim(0,vmax)

	plt.colorbar()
    
    
	plt.title('EELS_data', fontsize = 10)
	a,b=best_fit(np.ravel(clementanswer1[:,:]), np.ravel(outputtest1[:,:]),)
	yfit = [a + b * xi for xi in np.ravel(clementanswer1[:,:])]
	plt.plot(np.ravel(clementanswer1[:,:]), yfit,'--',color='b',linewidth=0.5)
	plt.annotate('R2= %.3f' % CoD1, (0.8, 0.2), xycoords='axes fraction', ha='center', va='center', size=10)
	plt.savefig("%s.pdf"%string1)    
	plt.show()

def plot_history(history):
    acc = history.history['acc']
    val_acc = history.history['val_acc']
    loss = history.history['loss']
    val_loss = history.history['val_loss']
    x = range(1, len(acc) + 1)

    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    plt.plot(x, acc, 'b', label='Training acc')
    plt.plot(x, val_acc, 'r', label='Validation acc')
    plt.title('Training and validation accuracy')
    plt.legend()
    plt.subplot(1, 2, 2)
    plt.plot(x, loss, 'b', label='Training loss')
    plt.plot(x, val_loss, 'r', label='Validation loss')
    plt.title('Training and validation loss')
    plt.legend()
from keras.callbacks import EarlyStopping
def deep_learningclass(inputtrainclass, outputtrainclass,filename):
    np.random.seed(5)
    from keras.utils import to_categorical
    from keras.layers import Dense
    from keras.models import Sequential
    outputtrainclasss = to_categorical(outputtrainclass)
    modelDNN = Sequential()

# Adding the input layer and the first hidden layer
    modelDNN.add(Dense(200, activation = 'relu', input_dim = numclement))

# Adding the second hidden layer
    modelDNN.add(Dense(units = 420, activation = 'relu'))

    modelDNN.add(Dense(units = 21, activation = 'relu'))

    modelDNN.add(Dense(nclusters, activation='softmax'))

    modelDNN.compile(loss= 'categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    es = EarlyStopping(monitor='val_acc', mode='max', verbose=1, patience=100)
# Fitting the ANN to the Training set
    history=modelDNN.fit(inputtrainclass, outputtrainclasss,validation_split=0.01, batch_size = 10, epochs = 300,callbacks=[es])
    plot_history(history)
    pickle.dump(modelDNN, open(filename, 'wb'))


def Get_training_data(data,train_percentage):
	value=int(train_percentage)/100
	valuetest=1-value
	output=data[:,[3]]
	input1=data[:,[0,1,2]]
	print('get training data and save indices')
	from sklearn.model_selection import train_test_split
	numrows=len(input1)
	indices = np.arange(numrows)
	train_x, test_x, train_y, test_y, train_indices, test_indices = train_test_split(input1, output, indices, test_size=valuetest)
	np.savetxt('trainX.out',train_x, fmt = '%4.4f',delimiter='\t', newline = '\n')
	np.savetxt('trainY.out',train_y, fmt = '%4.4f',delimiter='\t', newline = '\n')
	np.savetxt('testX.out',test_x, fmt = '%4.4f',delimiter='\t', newline = '\n')
	np.savetxt('testY.out',test_y, fmt = '%4.4f',delimiter='\t', newline = '\n')
	np.savetxt('indices_train.out',train_indices, fmt = '%4.4f',delimiter='\t', newline = '\n')
	np.savetxt('indices_test.out',test_indices, fmt = '%4.4f',delimiter='\t', newline = '\n')
	return train_x,train_y
	
print('-------------------BEGIN PROGRAM-----------------------------------')    
##---------------------Begin Program-------------------------------##

filename2= 'Claffiermodel1.asv'

#------------------Begin Code-------------------------------------------------------------------#
print('')
print('-------------------LOAD INPUT DATA-----------------------------------')
print('  Loading the ascii data ')

train_percentage=input(' Enter the amount of training data you want to use in percentage: ')
data=np.genfromtxt("data.out", dtype='float')

input1,output=Get_training_data(data,train_percentage)
test=data
output=np.reshape(output,(-1,1),'F')

print('')
print('Standardize and normalize the input data')
numrows1=len(input1)
input1=gaussianizeit(input1) 
scaler = MinMaxScaler()
(scaler.fit(input1))
input1=(scaler.transform(input1))

input11=input1
numrows=len(input1)    # rows of inout
numcols = len(input1[0])
inputtrain=(input1)
numclement = len(input1[0])
print('-------------------BEGIN MACHINE LEARNING----------------------------')

outputtrain=output 
outputtrain=gaussianizeit(outputtrain) 
ydamir=outputtrain
scaler1 = MinMaxScaler()
(scaler1.fit(ydamir))
ydamir=(scaler1.transform(ydamir))
ydami=numclement*1*ydamir

matrix=np.concatenate((inputtrain,ydami), axis=1)
i=1
kuse=getoptimumk(matrix,i)
print('')
print('the optimum number of clusters for the machine  is',kuse)
clement1=kuse
clement_cluster=kuse # 
nclusters=clement_cluster
print('')
print('Do the K-means clustering of [X,y] and get the labels')
#kmeans = MiniBatchKMeans(n_clusters=clement_cluster,random_state=0,batch_size=10,max_iter=20).fit(matrix)
kmeans =KMeans(n_clusters=clement_cluster,max_iter=1000,n_jobs=-1).fit(matrix)
#kmeans =MiniBatchKMeans(n_clusters=nclusters,max_iter=1000).fit(matrix)
dd=kmeans.labels_
dd=dd.T
dd=np.reshape(dd,(-1,1))
print('')
#-------------------#---------------------------------#
print('Use the labels to train a classifier')
inputtrainclass=inputtrain
outputtrainclass=np.reshape(dd,(-1,1))
print('')
print(' Learn the classifer from the predicted labels from Kmeans')

deep_learningclass(inputtrainclass, outputtrainclass,filename2)
#labelDA=run_model(modelclass,inputtrainclass, outputtrainclass,inputtest,filename2)

X_train=inputtrain
y_train=dd
y_test=dd
np.savetxt('y_train1.out',y_train, fmt = '%4.6f', newline = '\n')
np.savetxt('X_train1.out',X_train, fmt = '%4.6f', newline = '\n')
np.savetxt('y_traind1.out',ydamir, fmt = '%4.6f', newline = '\n')


#-------------------Regression---------------------------------------------------#
print('Learn regression of the clusters with different labels from k-means ' )
print('')
print('Start the regression')

oldfolder = os.getcwd()
os.chdir(oldfolder)

print('')

for j in range(nclusters):
    folder = 'CCRmodel1_%d'%(j)
    if os.path.isdir(folder): # value of os.path.isdir(directory) = True
        shutil.rmtree(folder)      
    os.mkdir(folder)
    shutil.copy2('y_train1.out',folder)
    shutil.copy2('X_train1.out',folder)
    shutil.copy2('y_traind1.out',folder)

def remove1():
	i=1
	os.chdir(oldfolder)
#	os.remove("inputtest%d.out"%(i))
	os.remove("X_train%d.out"%(i))
	os.remove("y_train%d.out"%(i))
	os.remove("y_traind%d.out"%(i))

      
remove1()

print('')
os.chdir(oldfolder)
##
import multiprocessing
import numpy as np
#from sklearn.neural_network import MLPRegressor

import os
from joblib import Parallel, delayed

filename1='regressor1.asv'
#
def parad(j):
    
    oldfolder = os.getcwd()
    folder = 'CCRmodel1_%d'%(j)
    os.chdir(folder)
    y_train=np.genfromtxt("y_train1.out", dtype='float')
    y_train = np.reshape(y_train,(-1,1), 'F') 
    X_train = np.genfromtxt("X_train1.out", dtype='float') 
    X_train = np.reshape(X_train,(-1,numclement), 'F') 
    y_traind = np.genfromtxt("y_traind1.out", dtype='float') 
    y_traind = np.reshape(y_traind,(-1,1), 'F') 
    label0=(np.asarray(np.where(y_train == j))).T
    from keras.layers import Dense
    from keras.models import Sequential
    np.random.seed(7)
    modelDNN = Sequential()
    modelDNN.add(Dense(200, activation = 'relu', input_dim = numclement))
    modelDNN.add(Dense(units = 420, activation = 'relu'))
    modelDNN.add(Dense(units = 21, activation = 'relu'))
    modelDNN.add(Dense(units = 1))
    modelDNN.compile(loss= 'mean_squared_error', optimizer='Adam', metrics=['mse'])
    es = EarlyStopping(monitor='val_loss', mode='min', verbose=1, patience=100)         
    a0=X_train[label0,:]
    a0=np.reshape(a0,(-1,numclement),'F')

    b0=y_traind[label0,:]
    b0=np.reshape(b0,(-1,1),'F')
    if a0.shape[0]!=0 and b0.shape[0]!=0:
        modelDNN.fit(a0, b0,validation_split=0.01, batch_size = 5, epochs = 300,callbacks=[es])
    pickle.dump(modelDNN, open(filename1, 'wb'))
    os.remove("y_train1.out")
    os.remove("X_train1.out")
    os.remove("y_traind1.out")
    
    os.chdir(oldfolder)
    print(" cluster %d has been processed"%(j))
    
print('')
print('cluster in parallel')
print('')
number_of_realisations = range(nclusters)
for j in range(nclusters):
    parad(j)
    
#Parallel(n_jobs=nclusters, verbose=50)(delayed(
#    parad)(j)for j in number_of_realisations)

print('---------------------End of training the machine for output 1---------')
oldfolder = os.getcwd()
clementbig=np.zeros((1,1))
clementbig[0,:]=clement1

for i in range (1):
    a=open("clustersizes.dat", "a+")
    a.write("%d \n" % (clementbig[i,:]))
    a.close()
print('-------------------END TRAINING PROGRAM------------------------------')    

