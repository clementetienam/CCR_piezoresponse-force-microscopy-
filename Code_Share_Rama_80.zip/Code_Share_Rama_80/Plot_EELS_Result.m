clc;
clear;
close all;
disp('This code is to plot the value of the reconstruction with CCR')
disp('@Author: Dr Clement Etienam')
disp('@Supervisor: Professor Kody Law')
load data.out;
load CCRprediction_big.out;

data=data(:,4);
CCR=CCRprediction_big(:,4);
Truedata=reshape(data,50,50,100);
CCR=reshape(CCR,50,50,100);

figure()
subplot(2,2,1)
redd=slice(Truedata,[1 50],[1 50],[1 100]);
axis equal on

shading flat
grid off
title('True','FontName','Helvetica', 'Fontsize', 16);
colormap('jet')
% caxis([min(output(:)) min(output(:))])
xlabel('X','FontName','Helvetica', 'Fontsize', 16)
ylabel('Y','FontName','Helvetica', 'Fontsize', 16)
zlabel('Z','FontName','Helvetica', 'Fontsize', 16)
set(gca, 'FontName','Helvetica', 'Fontsize', 16)
set(gcf,'color','white')


subplot(2,2,2)
redd2=slice(CCR,[1 50],[1 50],[1 100]);
axis equal on

shading flat
grid off
title('CCR','FontName','Helvetica', 'Fontsize', 16);
colormap('jet')
% caxis([min(output(:)) min(output(:))])
xlabel('X','FontName','Helvetica', 'Fontsize', 16)
ylabel('Y','FontName','Helvetica', 'Fontsize', 16)
zlabel('Z','FontName','Helvetica', 'Fontsize', 16)

set(gca, 'FontName','Helvetica', 'Fontsize', 16)
set(gcf,'color','white')



[X,Y] = meshgrid(1:50,1:50);
True=Truedata;
meantrue=mean(Truedata,3);
meanCCR=mean(CCR,3);

 subplot(2,2,3)

 surf(X',Y',meantrue)

shading flat
axis([1 50 1 50 ])
grid off
title ('Mean of True data','FontName','Helvetica', 'Fontsize', 13);
% title('Layer 2(best Log(K)-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap('jet')
minx=meantrue;
minx=minx(:);
a=min(minx);
b=max(minx);
caxis([a b])
h = colorbar;
ylabel(h, 'Values','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [a b])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


 subplot(2,2,4)

  surf(X',Y',meanCCR)

shading flat
axis([1 50 1 50 ])
grid off
title ('CCR mean','FontName','Helvetica', 'Fontsize', 13);
% title('Layer 2(best Log(K)-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap('jet')
minx=meantrue;
minx=minx(:);
a=min(minx);
b=max(minx);
caxis([a b])
h = colorbar;
ylabel(h, 'Values','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [a b])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca, 'FontName','Helvetica', 'Fontsize', 16)
set(gcf,'color','white')
saveas(gcf,'compare.pdf')